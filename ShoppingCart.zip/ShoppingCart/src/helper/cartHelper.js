import couponCodes from "./../json/coupon";

/* Update product on the cart */ 
export const updateCart = (cartProducts, product) => {
    if (cartProducts.length < 1) {
        cartProducts.push(product);
    } else {
        const productIndex = cartProducts.findIndex(cart => cart.id === product.id);
        if (productIndex >= 0) {
            cartProducts[productIndex].qty = cartProducts[productIndex].qty + product.qty;
        } else {
            cartProducts.push(product);
        }
    }
    return cartProducts;
};

/* Delete product from functionality */
export const deleteProducts = (cartProducts, product) => {
    const filterProducts = cartProducts.filter((cartProduct, index) => {
        return cartProduct.id !== product.id;
    });
    return filterProducts;
};

/* Update cart total functionality */
export const updateTotal = (products, coupon) => {
    let subTotal = 0, items = 0, grantTotal = 0;
    products.forEach(product => {
        subTotal += product.qty * product.price;
        items += product.qty;
    });
    if (coupon && coupon.percentage) {
        grantTotal = subTotal - (subTotal * coupon.percentage / 100);
    } else {
        grantTotal = subTotal;
    }
    return { subTotal, items, grantTotal }
}

/* Check given coupon code is available or not */
export const checkCouponCode = (couponcode) => {
    const coupon = couponCodes.filter(couponCode => {
        return couponcode === couponCode.code;
    });
    return coupon;
}

/* Back to redirect by given url */
export const locationHistory = (location) => {
     let splitVal='';
     location ? splitVal=location.split("=") : splitVal="";
     splitVal.length>0 && splitVal ? splitVal=splitVal[1] : splitVal="products";
     return splitVal;
}