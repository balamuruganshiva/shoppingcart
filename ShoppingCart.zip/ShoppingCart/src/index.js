import React, { Component } from 'react';
import { render } from 'react-dom';
import Login from './container/Login';
import Cart from './container/Cart';
import Products from './container/Products';
import Payment from './container/Payment';
import Success from './container/Success';
import Header from './container/Header';
import Footer from './container/Footer';
import Home from './container/Home';
import ProductView from './container/ProductView';
import { BrowserRouter, Route } from 'react-router-dom';
import { createStore, applyMiddleware } from 'redux';
import rootReducer from './reducer';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import './style.css';

const store = createStore(rootReducer, applyMiddleware(thunk));

class App extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }
  render() {
    return (
      <Provider store={store}>
        <BrowserRouter>
          <Route path="/" component={Header} />
          <Route exact path="/" component={Home} />
          <Route exact path="/login" component={Login} />
          <Route exact path="/products" component={Products} />
          <Route exact path="/productview/:productId" component={ProductView} />
          <Route exact path="/cart" component={Cart} />
          <Route exact path="/payment" component={Payment} />
          <Route exact path="/success" component={Success} />
          <Route path="/" component={Footer} />
        </BrowserRouter>
      </Provider>
    );
  }
}

render(<App />, document.getElementById('root'));
