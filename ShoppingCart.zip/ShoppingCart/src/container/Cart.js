import React from 'react';
import { connect } from 'react-redux';
import { Container, Button, Table, Col } from 'react-bootstrap';
import { couponCode, deleteProduct, deleteCoupon } from './../action/cart';
import MessageDisplay from './../component/MessageDisplay';
import { getCartTotal, getCartProducts, getCart, getCartCoupon, getUser } from './../utils/commonUtils';
import CartList from './../component/CartList';
import Coupon from './../component/Coupon';
import CartTotal from './../component/CartTotal';

const mapStateToProps = (state) => {
  return {
    products: getCartProducts(state, "cart.products"),
    cart: getCartTotal(state, "cart.totals"),
    coupon: getCartCoupon(state, "cart.coupon"),
    cartInfo: getCart(state, "cart"),
    user: getUser(state, "user.user")
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    couponCode: (cart, code, successCoupon,failureCoupon) => 
    dispatch(couponCode(cart, code, successCoupon,failureCoupon)),
    deleteProduct: (cart, product) => dispatch(deleteProduct(cart, product)),
    deleteCoupon: (cart,callBack) => dispatch(deleteCoupon(cart,callBack))
  }
}

class Cart extends React.Component {

  constructor(props) {
    super(props);
    this.couponcode = React.createRef();
    this.deleteProducts = this.deleteProducts.bind(this);
    this.sendCouponCode = this.sendCouponCode.bind(this);
    this.successCoupon = this.successCoupon.bind(this);
    this.failureCoupon = this.failureCoupon.bind(this);
    this.deleteCouponCode = this.deleteCouponCode.bind(this);
    this.state = {couponSFlag:false,couponFFlag:false,deleteFlag:false};
    this.deleteCallBack = this.deleteCallBack.bind(this);
  }

  componentDidMount(){
    if (!this.props.user.logged) {
      this.props.history.push('/login?back=cart');
    }
  }
   
  //CallBack function when meet success scenario
  successCoupon(){
    this.setState({successCoupon:true,failureCoupon:false,deleteFlag:false});
  }

  //CallBack function when meet failure scenario
  failureCoupon(){
    this.setState({failureCoupon:true,successCoupon:false,deleteFlag:false});
  }
  /*Update Coupon Code */
  sendCouponCode() {
    this.props.couponCode(this.props.cartInfo, this.couponcode.current.value,this.successCoupon,this.failureCoupon);
  }
  deleteCouponCode(){
    this.props.deleteCoupon(this.props.cartInfo,this.deleteCallBack);
  }
  deleteCallBack(){
    this.setState({failureCoupon:false,successCoupon:false,deleteFlag:true});
  }
  /* Delete product from Cart */
  deleteProducts(product) {
    this.props.deleteProduct(this.props.cartInfo, product);
  }

  render() {
    return (<div className="productlistmain">
      <div className="Header"><div className="headerLeft">Shopping Cart</div>

        <Button className="btnRight" onClick={() => this.props.history.push('/payment')}>Continue To Shopping</Button>
        <Button className="btnRight space" onClick={() => this.props.history.push('/products')}>Back To Purchase</Button></div>
      <Col xs lg="10" className="floatNone" >
        {this.props.products && this.props.products.length > 0 &&
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Item Name</th>
                <th className="itemImageLabel">Image</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>SubTotal</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {this.props.products &&
                this.props.products.map((product, index) =>
                  <CartList key={index} product={product} deleteProducts={this.deleteProducts}  />
                )}
            </tbody>
          </Table>}
      </Col>
      {this.props.products && this.props.products.length > 0 &&
        <Container className="">
          <Col lg="1"></Col>
          <Coupon successCoupon={this.state.successCoupon} failureCoupon={this.state.failureCoupon}
           sendCouponCode={this.sendCouponCode} couponcode={this.couponcode} 
           coupon={this.props.coupon} deleteCouponCode={this.deleteCouponCode} deleteFlag={this.state.deleteFlag} />
          <CartTotal cart={this.props.cart} coupon={this.props.coupon} 
          />
        </Container>}
      {this.props.products.length < 1 &&
        <MessageDisplay message="Your Shopping Cart Is Empty." />
      }
    </div>);
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Cart);