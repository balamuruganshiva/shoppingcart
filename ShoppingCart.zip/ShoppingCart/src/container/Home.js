import React from 'react';
import { Button, Col, } from 'react-bootstrap';
import { productList } from './../action/productlist';
import { connect } from 'react-redux';
import { getUser } from './../utils/commonUtils';
import { userLogout } from './../action/login';

const mapDispatchToProps = (dispatch) => {
    return {
      productList : () => dispatch(productList()),
      userLogout  : () => dispatch(userLogout())
    }
}

const mapStateToProps = (state) => {
    return {
        userDetails: getUser(state, "user")
    }
}

class Home extends React.Component {

    componentDidMount(){
        this.props.productList();
    }
    
    userLogOut(){
        this.props.userLogout();
        this.props.history.push("/login");
    }

    render() {
        return (
            <div className="productlistmain">
                <div className="Header"><div className="headerLeft">Dashboard</div></div>
                <Col xs lg="8" className="floatNone homeTop" >
                    <div>
                        <Col lg="6" md="6" sm="6" className="loginPage">
                            <div className="home">
                                {!this.props.userDetails.user.logged && <div>
                                <div className="txt">Login</div>
                                <div className="buttonRight">
                                    <Button onClick={()=>this.props.history.push("/login")}>Click To Login</Button>
                                </div> </div>}
                                {this.props.userDetails.user.logged && <div>
                                <div className="txt">Logout</div>
                                <div className="buttonRight">
                                    <Button onClick={()=>this.userLogOut()}>Click To Logout</Button>
                                </div> </div>}
                            </div>
                        </Col>
                        <Col lg="6" md="6" sm="6" className="productPage ">
                            <div className="home">
                                <div className="txt">Product</div>
                                <div className="buttonRight">
                                    <Button onClick={()=>this.props.history.push("/products")}>Click To Prduct</Button>
                                </div>
                            </div>
                        </Col>
                        <Col lg="6" md="6" sm="6" className="cartPage ">
                            <div className="home">
                                <div className="txt">Cart</div>
                                <div className="buttonRight">
                                    <Button onClick={()=>this.props.history.push("/cart")}>Click To Cart</Button>
                                </div>
                            </div>
                        </Col>
                        <Col lg="6" md="6" sm="6" className="orderPage ">
                            <div className="home">
                                <div className="txt">Order</div>
                                <div className="buttonRight">
                                    <Button onClick={()=>this.props.history.push("/success")}>Click To Order</Button>
                                </div>
                            </div>
                        </Col>
                    </div>
                </Col>
            </div>);
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Home);