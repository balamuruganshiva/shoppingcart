import React from 'react';
import logo from './../img/logo.png';
import { connect } from 'react-redux';
import { Col, Navbar, Nav } from 'react-bootstrap';
import { getUser, getCart } from './../utils/commonUtils';
import {userLogout} from './../action/login';

const mapStateToProps = (state) => {
    return {
        userDetails: getUser(state, "user"),
        cart: getCart(state, "cart")
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        userLogout: () => dispatch(userLogout())
    }
}
class Header extends React.Component {

    userLogOut(){
        this.props.userLogout();
        this.props.history.push("/login");
    }
    render() {
        return (<div className="HeaderTop">
            <Col lg="3" md="2" sm="3" className="headLogo">
                <img className="logoImg" src={logo} alt="Logo" />
            </Col>
            <Col lg="6" md="8" sm="6" className="headMenu">
                <div className="menuNav">
                    <Navbar bg="dark" variant="dark">
                        <Nav className="mr-auto">
                            <Nav.Link onClick={() => this.props.history.push("/")}>Home</Nav.Link>
                            {!this.props.userDetails.user.logged && 
                            <Nav.Link onClick={() => this.props.history.push("/login")}>Login
                            </Nav.Link>}
                            {this.props.userDetails.user.logged && 
                            <Nav.Link onClick={() => this.userLogOut()}>Logout
                            </Nav.Link>}
                            <Nav.Link onClick={() => this.props.history.push("/products")}>Product</Nav.Link>
                            <Nav.Link onClick={() => this.props.history.push("/cart")}>Cart</Nav.Link>
                            <Nav.Link onClick={() => this.props.history.push("/success")}>Order</Nav.Link>
                        </Nav>
                    </Navbar>
                </div>
            </Col>
            <Col lg="3" md="2" sm="3" className="headUser">
                <div className="HeaderTopRight">
                    <div className="welcomeText">Welcome :
                {!this.props.userDetails.user.userName ? " Anonymous" : <span>
                            {this.props.userDetails.user.userName}</span>}
                    </div>
                    <div className="CartSummary">
                        {this.props.cart.totals && this.props.cart.totals.items > 0 &&
                            <div className="cartTop">
                                YourCart :
              <div className="">Items: {this.props.cart.totals.items}</div>
                                <div className="">SubTotal: $ {this.props.cart.totals.subTotal}</div>
                            </div>}
                    </div>
                </div>
            </Col>
        </div>);
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Header);