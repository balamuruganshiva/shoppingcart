import React from 'react';
import { connect } from 'react-redux';
import { Container, Button, Table, Col, Alert } from 'react-bootstrap';
import { reCart } from './../action/cart';
import { reOrder } from './../action/payment';
import MessageDisplay from './../component/MessageDisplay';
import OrderList from './../component/OrderList';
import OrderTotal from './../component/OrderTotal';
import {getOrderProducts, getOrderCoupon, getUser, getOrderTotals, getOrderPayment, getOrder} from './../utils/commonUtils';
const mapStateToProps = (state) => {
  return {
    products: getOrderProducts(state, "paymentInfo.order.products"),
    cart: getOrderTotals(state, "paymentInfo.order.totals"),
    coupon: getOrderCoupon(state, "paymentInfo.order.coupon"),
    payment: getOrderPayment(state, "paymentInfo.payment"),
    order: getOrder(state, "paymentInfo.order"),
    user: getUser(state, "user.user")
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    reCart: (cart) => dispatch(reCart(cart)),
    reOrder: () => dispatch(reOrder())
  }
}

class Success extends React.Component {
  
  /* Reorder the items */
  reOrder() {
    this.props.reCart(this.props.order);
    this.props.reOrder();
    this.props.history.push("/cart");
  }

  componentDidMount(){
    if (!this.props.user.logged) {
      this.props.history.push('/login?back=success');
    }
  }

  render() {
    return (<div className="productlistmain">
      <div className="Header">
        <div className="headerLeft"><Col lg="6" md="6" sm="6" xs>Order Summary</Col></div>
        <div className="headerRight"><Col lg="6" sm="6" md="6" xs>
          <Button className="btnRight" onClick={() => this.reOrder()}>Reorder</Button>
          <Button className="btnRight space" onClick={() => this.props.history.push('/products')}>
            Back To Purchase</Button>
        </Col></div>
      </div>
      {this.props.products.length > 0 && <div>
        <Container>

          <Alert variant="success">
            Thanks for ordering the Items.
      </Alert>
          <Col xs lg="10" className="floatNone" >

            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Item Name</th>
                  <th>Image</th>
                  <th>Quantity</th>
                  <th>Price</th>
                  <th>SubTotal</th>
                </tr>
              </thead>
              <tbody>
                {this.props.products &&
                  this.props.products.map((product, index) => 
                    <OrderList product={product} key={index} />
                  )}
              </tbody>
            </Table>
          </Col>
        </Container>

        <Container className="">
          <OrderTotal products={this.props.products}
            cart={this.props.cart} coupon={this.props.coupon} payment={this.props.payment}
          />
        </Container></div>}
      {this.props.products.length < 1 &&
        <MessageDisplay message="Your Shopping Cart Is Empty. Please Make a new Order" />
      }
    </div >);
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Success);