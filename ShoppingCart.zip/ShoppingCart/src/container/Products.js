import React from 'react';
import { connect } from 'react-redux';
import ProductList from './../component/ProductList';
import { Button, Col } from 'react-bootstrap';
import { addToProduct } from './../action/cart';
import InfiniteScroll from "react-infinite-scroll-component";
import LoadImg from './../img/LoadImg.gif';
import { getProductList, getCartProducts, getCart } from './../utils/commonUtils';

const mapStateToProps = (state) => {
  return {
    products: getProductList(state, "productList.products"),
    cartProducts: getCartProducts(state, "cart.products"),
    cart: getCart(state, "cart")
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    addToProduct: (cartProducts, product) => dispatch(addToProduct(cartProducts, product))
  }
}

class Products extends React.Component {

  constructor(props) {
    super(props);
    this.addToProdcucts = this.addToProdcucts.bind(this);
    this.state = {
      activePage: 1,
      pLen: Math.ceil(this.props.products.length / 4),
      products: this.props.products.length > 0 ? this.props.products.slice(0, 4) : [],
      hasMore: true
    };
    this.fetchMoreData = this.fetchMoreData.bind(this);
    this.viewProduct = this.viewProduct.bind(this);
  }

  /* Add product to the cart */
  addToProdcucts(product) {
    this.props.addToProduct(this.props.cart, product);
  }

  /* Redirect to View page with param ID */
  viewProduct(id) {
    this.props.history.push("/productview/" + id);
  }

  /* Fetch Data while meet scroll dowwn */
  fetchMoreData() {
    let setPage = this.state.activePage + 1;
    if (this.state.activePage < this.state.pLen) {
      setTimeout(() => {
        this.setState({
          activePage: setPage,
          products: this.state.products.concat(this.props.products.slice((setPage * 4) - 4, setPage * 4))
        })
      }, 2000);
    } else {
      this.setState({ hasMore: false });
    }
  }
  render() {
    return (<div className="productlistmain category">
      <div className="Header">
        <div className="headerLeft"><Col lg="6" md="6" sm="6" xs>Products</Col></div>
        <div className="headerRight"><Col lg="6" sm="6" md="6" xs>
          <Button className="btnRight" onClick={() => this.props.history.push('/cart')}>Continue To Shopping</Button>
        </Col></div>
      </div>
      {this.props.products.length>0 && <InfiniteScroll
        dataLength={this.state.products.length}
        next={this.fetchMoreData}
        hasMore={this.state.hasMore}
        loader={<h4><img src={LoadImg} alt="Loading ...." /></h4>}
      >
        {this.state.products.length > 0 && this.state.products.map((product, index) => {
          return (<ProductList
            product={product} key={index} cartProducts={this.props.cartProducts}
            addToCart={this.addToProdcucts} viewProduct={this.viewProduct} />)
        })
        }
      </InfiniteScroll>}
    </div>);
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Products);