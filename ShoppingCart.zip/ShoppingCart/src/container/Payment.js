import React from 'react';
import { Form, Container, Col, Button } from 'react-bootstrap';
import { paymentProcess } from './../action/payment';
import { connect } from 'react-redux';
import { deleteCart } from './../action/cart';
import MessageDisplay from './../component/MessageDisplay';
import CashOnPayment from './../component/CashOnPayment';
import CreditCardPayment from './../component/CreditCartPayment';
import DebitCardPayment from './../component/DebitCardPayment';
import { getCart, getPaymentInfo } from './../utils/commonUtils';

const mapStateToPros = (state) => {
    return {
        payment: getPaymentInfo(state, "paymentInfo"),
        cart: getCart(state, "cart")
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        deleteCart: () => dispatch(deleteCart()),
        paymentProcess: (payment, cart, succssPage) => dispatch(paymentProcess(payment, cart, succssPage))
    }
}

class Payment extends React.Component {

    constructor(props) {
        super(props);
        this.cash = React.createRef();
        this.cNum = React.createRef();
        this.cCVV = React.createRef();
        this.cExpDate = React.createRef();
        this.dNum = React.createRef();
        this.dCVV = React.createRef();
        this.dExpDate = React.createRef();
        this.cashOnPayment = this.cashOnPayment.bind(this);
        this.creditPayment = this.creditPayment.bind(this);
        this.debitPayment = this.debitPayment.bind(this);
        this.state = { "cash": false, "Cflag": false, "dFlag": false,cValidation:true,dValidation:true,cashValidation:true };
        this.succssPage = this.succssPage.bind(this);

    }

    //Credit Card Payment when Choose payment method as Cridit Card
    cashOnPayment() {
        let setFlag = false;
        this.cash.current.value ? setFlag = true : setFlag = false;
        this.cash.current.value ? this.setState({cashValidation:true}):this.setState({cashValidation:false})
        if(setFlag){
        this.props.paymentProcess({ type: "Cash", amt: this.cash.current.value },
            this.props.cart, this.succssPage);
        }
    }

    //Credit Card Payment when Choose payment method as Cridit Card
    creditPayment() {
        const cNum = this.cNum.current.value,cCVV = this.cCVV.current.value,
        cExpDate = this.cExpDate.current.value;
        let setFlag=false;
        (cNum && cCVV && cExpDate) ? setFlag=true:setFlag=false;
        setFlag ? this.setState({cValidation:true}):this.setState({cValidation:false});
        const payment = { type: "Credit Card", cNum, cCVV, cExpDate, success: 1 };
        if(setFlag){
        this.props.paymentProcess(payment, this.props.cart, this.succssPage);
        }
    }
    
    //Debit Card Payment when Choose payment method as Debit Card
    debitPayment() {
        const dNum = this.dNum.current.value,dCVV = this.dCVV.current.value,
        dExpDate = this.dExpDate.current.value;
        let setFlag=false;
        (dNum && dCVV && dExpDate) ? setFlag=true:setFlag=false;
        setFlag?this.setState({dValidation:true}):this.setState({dValidation:false});
        const payment = { type: "Debit Card", dNum, dCVV, dExpDate, success: 1 }
        if(setFlag){
        this.props.paymentProcess(payment, this.props.cart, this.succssPage);
        }
    }
    
    //Redirect to Success Page, Once Payment has done Successfully
    succssPage() {
        this.props.deleteCart();
        this.props.history.push('/success');
    }

    render() {
        return (<div className="productlistmain">
            <div className="Header">
                <div className="headerLeft"><Col lg="6" md="6" sm="6" xs>Payment</Col></div>
                <div className="headerRight"><Col lg="6" sm="6" md="6" xs>
                    <Button className="btnRight" onClick={() => this.props.history.push('/products')}>Continue To Shopping</Button>
                </Col></div>
            </div>

            <div className="paymentForm">
                {this.props.cart.products.length > 0 &&
                    <Container>
                        <Col lg="5">
                            <div className="productlistmain">
                                <div className="Header">Paymet Option</div>
                                <Form.Group controlId="formBasicEmail">
                                    <Form.Check className="text-muted" name="formHorizontalRadios"
                                        type="radio" label="Cash on money"
                                        onClick={() => this.setState({ cash: true, cFlag: false, dFlag: false })}></Form.Check>

                                    <Form.Check className="text-muted" name="formHorizontalRadios"
                                        type="radio" label="Debit Card"
                                        onClick={() => this.setState({ cash: false, cFlag: false, dFlag: true })}></Form.Check>
                                    <Form.Check name="formHorizontalRadios"
                                        className="text-muted" type="radio" label="Credit Card"
                                        onClick={() => this.setState({ cash: false, cFlag: true, dFlag: false })}
                                    >
                                    </Form.Check>
                                </Form.Group>
                            </div>
                        </Col>
                        {this.state.cash && <Col lg="6">
                            <CashOnPayment cash={this.cash}
                                cashOnPayment={this.cashOnPayment} cashValidation={this.state.cashValidation} />
                        </Col>}
                        {this.state.cFlag &&
                            <Col lg="6">
                                <CreditCardPayment cNum={this.cNum} cValidation={this.state.cValidation}
                                    cCVV={this.cCVV} cExpDate={this.cExpDate} creditPayment={this.creditPayment}
                                />
                            </Col>}
                        {this.state.dFlag &&
                            <Col lg="6">
                                <DebitCardPayment dNum={this.dNum} dValidation={this.state.dValidation}
                                    dCVV={this.dCVV} dExpDate={this.dExpDate} debitPayment={this.debitPayment}
                                />
                            </Col>}

                    </Container>}
                {this.props.cart.products.length < 1 &&
                    <MessageDisplay message="Your Shopping Cart Is Empty. Not Authorized to proceed this page." />
                }
            </div>
        </div>);

    }
}
export default connect(mapStateToPros, mapDispatchToProps)(Payment);