import React from 'react';
import { connect } from 'react-redux';
import { getProduct } from './../utils/commonUtils';
import { Col, Button } from 'react-bootstrap';
import { addToProduct } from './../action/cart';
const mapStateProps = (state, props) => {
    return {
        product: getProduct(state.productList.products, parseInt(props.match.params.productId)),
        cart: state.cart
    }
};
const mapDispatchToProps = (dispatch) => {
    return {
        addToProduct: (cartProducts, product) => dispatch(addToProduct(cartProducts, product))
    }
}
class ProductView extends React.Component {
    constructor(props) {
        super(props);
        this.state = { qty: 1, disabled: true };
        this.qty = React.createRef();
    }

    /* Add product to the cart */
    addToCarts() {
        const product = {
            id: this.props.product.id,
            name: this.props.product.name, price: this.props.product.price, qty: parseInt(
                this.qty.current.value)
            , src: this.props.product.src
        };
        this.props.addToProduct(this.props.cart, product);
    }

    /* Decrease the quantity while click the button */
    minusQty() {
        let qty = this.state.qty - 1;
        qty < 2 ? this.setState({ qty, disabled: true }) : this.setState({ qty });
    }

    /* Increase the quantity while click the button */
    plusQty() {
        this.state.qty > 0 ? this.setState({ qty: this.state.qty + 1, disabled: false }) : this.setState({ disabled: true });
    }

    render() {
        return (<div className="productlistmain category">
            <div className="Header">
                <div className="headerLeft"><Col lg="6" md="6" sm="6" xs>Product View</Col></div>
                <div className="headerRight"><Col lg="6" sm="6" md="6" xs>
                    <Button className="btnRight" onClick={() => this.props.history.push('/products')}>
                        Back To List</Button>
                </Col></div></div>
            {this.props.product && <div className="">
                <Col lg="6" md="6" sm="6">
                    <div className="productLeft">
                        <div className="productName">{this.props.product.name}</div>
                        <div className="productImg" >
                            <img src={this.props.product.src} alt={this.props.product.name} /></div>
                    </div>
                </Col>
                <Col lg="6" md="6" sm="6" className="offset-lg-1">
                    <div className="productRight">
                        <div className="pvSpace"><b>Product Name</b> : {this.props.product.name}</div>
                        <div className="pvSpace"><b>Price </b>: ${this.props.product.price}</div>
                        <div className="pvSpace"><b>Discription</b>:</div>
                        <div className="pvSpace"> Dummy text is also used to demonstrate the 
                        appearance of different typefaces and layouts, and in general the content 
                        of dummy text is nonsensical. Due to its widespread use as filler text for 
                        layouts, non-readability is of great importance: human perception is
                             tuned to recognize certain patterns and repetitions in texts.</div>
                        <div className="pvSpace"><b>Quantity :</b></div>
                        <div className="qty">
                            <Button disabled={this.state.disabled} onClick={() => this.minusQty()}>-</Button>
                            <input type="" value={this.state.qty} ref={this.qty} readOnly />
                            <Button onClick={() => this.plusQty()}>+</Button></div>
                        <div className="pvSpace">
                            <Button onClick={() => this.addToCarts()}>Add To Cart</Button>
                        </div>
                    </div>
                </Col>
            </div>}
        </div>);
    }
}
export default connect(mapStateProps, mapDispatchToProps)(ProductView);