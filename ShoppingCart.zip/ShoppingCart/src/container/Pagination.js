import React from 'react';

export default class Pagination extends React.Component {

    render() {
        return(<div>Bala{this.props.count}{this.props.pagePerCount}</div>);
    }
}