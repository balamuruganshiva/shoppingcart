import React from 'react';
import { userLogin } from './../action/login';
import { connect } from 'react-redux';
import { Button } from 'react-bootstrap';
import { Form, Col, Row, Container, Alert } from "react-bootstrap";
import { getUser, getErrorMsg} from './../utils/commonUtils'
import {locationHistory} from './../helper/cartHelper';

const mapDispatchToProps = (dispatch) => {
  return {
    userLogin: () => dispatch(userLogin())
  }
}
const mapStateToProps = (state) => {
  return {
    errorMsg: getErrorMsg(state, "user.errorMsg"),
    user: getUser(state, "user.user")
  }
}
class Login extends React.Component {
  constructor(props) {
    super(props);
    this.uname = React.createRef();
    this.pwd = React.createRef();
  }
  submitUser() {
    const userName = this.uname.current.value,pwd = this.pwd.current.value;
    localStorage.setItem('uname', userName);
    localStorage.setItem('pwd', pwd);
    this.props.userLogin();
  }
  componentDidMount(){
    if(this.props.user.logged){
      this.props.history.push("/products");
    }
  }
  componentDidUpdate(nextProps) {
    if (nextProps.user.logged !== this.props.user.logged) {
      if (this.props.user.logged) {
        const backString = locationHistory(this.props.location.search);
        this.props.history.push('/'+backString);
      } else {
        this.props.history.push('/login');
      }
    }
  }
  render() {
      return (
      <div>
        <Container>
          <Row className="justify-content-md-center">
            <Col xs lg="6" className="floatNone" >
              <div className="LoginForm">
                {this.props.errorMsg && this.props.errorMsg.msg && <Alert variant={"danger"}>
                  {this.props.errorMsg.msg}</Alert>}
                <div className="Header">Login</div>
                <Form>
                  <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control type="input" required placeholder="Enter email" ref={this.uname} />
                    <Form.Text className="text-muted">
                      We'll never share your email with anyone else.
                    </Form.Text>
                  </Form.Group>
                  <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" ref={this.pwd} />
                  </Form.Group>
                  <Button variant="primary" type="button" onClick={() => this.submitUser()}>
                    Submit
                  </Button>
                </Form>
              </div>
            </Col></Row>
        </Container>
      </div>
    );
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Login);