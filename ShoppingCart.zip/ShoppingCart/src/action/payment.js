/* Payment action */
export const paymentProcess = (payment, cart, callBack) => {
  return dispatch => {
    dispatch(addPaymentInfo(payment));
    dispatch(order(cart));
    callBack();
  }
}

const addPaymentInfo = (payment) => {
  return {
    type: "PAYMENT",
    payment
  };
}

const order = (order) => {
  return {
    type: "ORDER",
    order
  };
}

/* Re Order functionality  */
export const reOrder = () => {
  return {
    type: "REORDER",
    reorder: 1
  }
}