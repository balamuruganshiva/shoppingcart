import products from './../json/products';
/* Get Products from json and store to the redux store */
export const productList = () => {
  return {
    type: "ADD_PRODUCT_LIST",
    products
  }
}
