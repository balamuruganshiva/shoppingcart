import userDetails from './../json/user';

/* User Login Functionality */
export const userLogin = () => {
  return (dispatch) => {
    const uname = localStorage.getItem("uname");
    const pwd = localStorage.getItem("pwd");
    const userDetail = checkLoginUser(userDetails, uname, pwd);
    if (userDetail) {
      userDetail.logged = 1;
      dispatch(Userdata(userDetail));
    } else {
      const errorMsg = { 'msg': 'Invalid User Name and Password' };
      dispatch(LoginError(errorMsg));
    }
  }
}

/* User Log out */

export const userLogout = () => {
  return (dispatch) => {
    localStorage.setItem("uname","");
    localStorage.setItem("pwd","");
    const userDetail = {};
    dispatch(Userdata(userDetail));
  }
}

const Userdata = (userDetail) => {
  return {
    type: 'USER_LOGIN',
    userDetail
  }
}

const LoginError = (errorMsg) => {
  return {
    type: 'LOGIN_ERROR',
    errorMsg
  }
}

const checkLoginUser = (userDetails, uname, pwd) => {
  if (userDetails) {
    const users = userDetails.filter(userDetail => { return userDetail.userName === uname && userDetail.pwd === pwd });
    return users[0];
  }
}