import { updateCart, updateTotal, checkCouponCode, deleteProducts } from './../helper/cartHelper';

/* Add product to the  cart */
export const addToProduct = (cart, product) => {
    return dispatch => {
        const products = updateCart(cart.products, product);
        const carts = updateTotal(products, cart.coupon);
        dispatch(updatePrduct(products));
        dispatch(updateCartAmount(carts));
    }
}
/* Delete product from the cart */
export const deleteProduct = (cart, product) => {
    return dispatch => {
        const products = deleteProducts(cart.products, product);
        const carts = updateTotal(products, cart.coupon);
        dispatch(updatePrduct(products));
        dispatch(updateCartAmount(carts));
    }
}

const updatePrduct = products => {
    return {
        type: "ADD_CART_LIST",
        products
    }
}
const updateCartAmount = cart => {
    return {
        type: "UPDATE_CART",
        cart
    }
}

/* Apply coupon code on the cart*/
export const couponCode = (cart, code, successCallBack, failureCallBack) => {
    return dispatch => {
        const applyCoupon = checkCouponCode(code);
        if (applyCoupon.length > 0) {
            dispatch(upDateCoupon(applyCoupon[0]));
            const carts = updateTotal(cart.products, applyCoupon[0]);
            dispatch(updateCartAmount(carts));
            successCallBack();
        } else {
            dispatch(upDateCoupon({}));
            const carts = updateTotal(cart.products, {});
            dispatch(updateCartAmount(carts));
            failureCallBack();
        }
    }
}

/* Delete coupon code from the cart*/
export const deleteCoupon = (cart, callBack) => {
    return dispatch => {
        dispatch(upDateCoupon({}));
        const carts = updateTotal(cart.products, {});
        dispatch(updateCartAmount(carts));
        callBack();
    }
}
export const upDateCoupon = coupon => {
    return {
        type: "COUPON",
        coupon
    }
}

/* Delete all the products from the cart */
export const deleteCart = () => {
    return {
        type: "DELETE_CART",
        delete: ""
    }
}

/* Re create the cart form exist */
export const reCart = (cart) => {
    return {
        type: "RECART",
        cart
    }
}