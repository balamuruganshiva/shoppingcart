export const productList = (state={products:[]},action) =>{
    switch(action.type){
      case 'ADD_PRODUCT_LIST':
      return { ...state, products: action.products };
      default:
      return state;
    }
}