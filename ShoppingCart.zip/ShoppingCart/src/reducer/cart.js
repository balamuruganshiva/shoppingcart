export const cart = (state = { products: [], totals: {}, coupon: {} }, action) => {
  switch (action.type) {
    case 'ADD_CART_LIST':
      return { ...state, products: action.products };
    case 'UPDATE_CART':
      return { ...state, totals: action.cart };
    case 'COUPON':
      return { ...state, coupon: action.coupon };
    case 'DELETE_CART':
      return {
        ...state,
        coupon: {},
        products: [],
        totals: {}
      };
    case 'RECART':
      return {
        ...state,
        coupon: action.cart.coupon,
        products: action.cart.products,
        totals: action.cart.totals
      };
    default:
      return state;
  }
}