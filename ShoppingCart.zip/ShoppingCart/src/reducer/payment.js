export const paymentInfo = (state = {
  payment: {}, order: {
    products: [],
    totals: {}, coupon: {}
  }
}, action) => {
  switch (action.type) {
    case 'PAYMENT':
      return { ...state, payment: action.payment };
    case 'ORDER':
      return {
        ...state, order: {
          ...state.order,
          products: action.order.products,
          totals: action.order.totals,
          coupon: action.order.coupon
        }
      };
    case "REORDER":
      return {
        ...state, order: {
          ...state.order,
          products: [],
          totals: {},
          coupon: {}
        },
        payment: {}
      };

    default:
      return state;
  }
}