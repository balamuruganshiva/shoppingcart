export const user = (state = { user: {}, errorMsg: {}, location: "" }, action) => {
  switch (action.type) {
    case 'USER_LOGIN':
      return { ...state, user: action.userDetail };
    case 'LOGIN_ERROR':
      return { ...state, errorMsg: action.errorMsg };
    case 'LOGOUT':
      return state = { user: {}, errorMsg: {} };
    case 'LOCATION':
      return { ...state, location: action.city };
    default:
      return state;
  }
}