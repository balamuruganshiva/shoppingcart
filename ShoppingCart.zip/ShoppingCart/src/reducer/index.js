import {user} from './login';
import {productList} from './products';
import {cart} from './cart';
import {paymentInfo} from './payment';
import { combineReducers } from 'redux';

const rootReducer = combineReducers({user,productList,cart,paymentInfo});
export default rootReducer;