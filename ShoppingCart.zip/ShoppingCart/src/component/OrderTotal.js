import React from 'react';
import {Col, Table} from 'react-bootstrap';

export default class OrderTotal extends React.PureComponent {

    render() {
        return (<Col xs lg="10" className="floatNone">
            <div className="productlistmain cartBottom">
                <div className="Header">Cart Total</div>
                <div>
                    <Table striped bordered hover>

                        {this.props.products && <tbody>
                            <tr>
                                <td>Items</td>
                                <td>{this.props.cart.items}</td>
                            </tr>
                            <tr>
                                <td>Sub Total</td>
                                <td>${this.props.cart.subTotal}</td>
                            </tr>
                            {this.props.coupon && this.props.coupon.percentage &&
                                <tr>
                                    <td>Discount: {this.props.coupon.code}</td>
                                    <td>{this.props.coupon.percentage}%</td>
                                </tr>
                            }
                            {this.props.payment && this.props.payment.type &&
                                <tr>
                                    <td>Payment  Mode</td>
                                    <td>{this.props.payment.type}</td>
                                </tr>
                            }
                            <tr>
                                <td>Total</td>
                                <td>${this.props.cart.grantTotal}</td>
                            </tr></tbody>
                        }
                    </Table>
                </div>
            </div>
        </Col>
        );
    }
}