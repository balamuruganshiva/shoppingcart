import React from 'react';
import {Form,Button,Alert} from 'react-bootstrap';

export default class CashOnPayment extends React.PureComponent {
    render() {
        return (<div className="productlistmain">
            <div className="Header">Cash On Payment</div>
            {!this.props.cashValidation && <Alert variant="danger">Please fill the below fields.
            </Alert>}
            <Form.Group controlId="CreditCard">
                <Form.Label>Amount</Form.Label>
                <Form.Control type="input" required ref={this.props.cash}
                    placeholder="Enter the Amount" />
                <Form.Text className="text-muted">
                    <sup>*</sup>Enter the amount.
           </Form.Text>
            </Form.Group>
            <Button onClick={() => this.props.cashOnPayment()}>Payment Order</Button>
        </div>);
    }
}