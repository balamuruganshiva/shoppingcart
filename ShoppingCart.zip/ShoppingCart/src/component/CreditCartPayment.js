import React from 'react';
import { Form, Button, Alert } from 'react-bootstrap';

export default class CreditCartPayment extends React.PureComponent {
    render() {
        return (<div className="productlistmain">
            <div className="Header">Credit Card Payment</div>
            {!this.props.cValidation && <Alert variant="danger">Please fill the below fields.{this.props.cValidation}
            </Alert>}
            <Form.Group controlId="CreditCard">
                <Form.Label>Card Number</Form.Label>
                <Form.Control type="input"
                    ref={this.props.cNum} placeholder="Enter Credit card number" />
                <Form.Text className="text-muted" required>
                    <sup>*</sup>Give 16 digit number.
</Form.Text>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>CVV</Form.Label>
                    <Form.Control type="input" required ref={this.props.cCVV} placeholder="Enter CVV Number" />
                    <Form.Text className="text-muted">
                        <sup>*</sup>Give 3 digit number.
</Form.Text>
                </Form.Group>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Expire Date</Form.Label>
                    <Form.Control type="input" required ref={this.props.cExpDate} placeholder="Enter Expire Date  MM/YYYY" />
                    <Form.Text className="text-muted">
                        <sup>*</sup>Format : MM/YYYY.
</Form.Text>
                </Form.Group>
                <Button onClick={() => this.props.creditPayment()} >Payment Order</Button>
            </Form.Group>
        </div>);
    }
}