import React from 'react';
import { Button, Modal } from 'react-bootstrap';

export default class CartList extends React.Component {

    constructor(props) {
        super(props);
        this.state = { show: false }
    }

    delete(product) {
        this.props.deleteProducts(product);
        this.setState({ show: false });
    }

    render() {
        return (<tr>
            <td>{this.props.product.name}</td>
            <td className="itemImage"><div className="imgSrc"><img src={this.props.product.src} alt={this.props.product.name} /></div></td>
            <td>{this.props.product.qty}</td>
            <td>${this.props.product.price}</td>
            <td>${this.props.product.qty * this.props.product.price}</td>
            <td>
                <Button className="btn btn-danger"
                    onClick={() => this.setState({ show: true })}>
                    Delete</Button>
            </td>
            <Modal show={this.state.show} onClick={() => this.setState({ show: false })}>
                <Modal.Header closeButton>
                    <Modal.Title>Delete product from the cart</Modal.Title>
                </Modal.Header>
                <Modal.Body>Do you want to delete {this.props.product.name} form this cart.</Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={() => this.delete(this.props.product)}>
                        Yes
            </Button>
                    <Button variant="primary" onClick={() => this.setState({ show: false })} >
                        No
            </Button>
                </Modal.Footer>
            </Modal>
        </tr>);
    }
}