import React from 'react';
import { Col, Form, Row, Button, Alert } from 'react-bootstrap';

export default class Coupon extends React.PureComponent {
    render() {
        return (<Col xs lg="5" sm="6" md="6" className="rightCutter">
            <div className="productlistmain cartBottom">
                <div className="Header">Coupon Code</div>
                {this.props.successCoupon && <Alert variant="success">
                    Coupon Code has Applied Successfully.
                </Alert>}
                {this.props.deleteFlag && <Alert variant="success">
                    Coupon Code has deleted Successfully.
                </Alert>
                }
                {this.props.failureCoupon && <Alert variant="danger">
                    InCorrect Coupon Code.
                </Alert>}
                <Row>
                    <Form>
                        <Form.Row>
                            <Col lg="8">
                                {!this.props.coupon.code && 
                                <Form.Control placeholder="Coupon Code" ref={this.props.couponcode} />
                                }
                                {this.props.coupon.code && 
                                <div className="couponCode">{this.props.coupon.code}</div>
                                }
                                </Col>
                            <Col lg="4">
                            {!this.props.coupon.code && 
                               <Button onClick={() => this.props.sendCouponCode()}>Submit</Button>
                            }
                            {this.props.coupon.code && 
                               <Button onClick={() => this.props.deleteCouponCode()}>Delete</Button>
                            }
                                </Col>
                        </Form.Row>
                    </Form>
                </Row>
            </div>
        </Col>
        )
    }
}