import React from 'react';
import { Col, Button } from 'react-bootstrap';

export default class ProductList extends React.PureComponent {

   // Trigger cart action function when click the AddToCart Button
   constructor(props){
      super(props);
      this.state = {name:"bala"};
   }
   
   componentDidMount(){
      this.setState({name:"murugan"});
   }
   addToCarts() {
      const product = {
         id: this.props.product.id,
         name: this.props.product.name, price: this.props.product.price, qty: 1
         , src: this.props.product.src
      };
      this.props.addToCart(product);
   }

   render() {
      return (
         <Col xs="12" sm="6" md="6" lg="4">
            {this.state.name}
            <div className="productlist">
               <div className="pname plabel">{this.props.product.name}</div>
               <div className="ImageClass" ><img src={this.props.product.src} alt={this.props.product.name} /></div>
               <div className="pprice plabel">${this.props.product.price}</div>
               <div className="pstck plabel">Stock : {this.props.product.qty}</div>
               <div className="addtocart plabel">
                  <Button onClick={() => this.props.viewProduct(this.props.product.id)}>View Product</Button></div>
               <div className="addtocart plabel">
                  <Button onClick={() => this.addToCarts()}>Add To Cart</Button></div>
            </div></Col>
      );
   }
}