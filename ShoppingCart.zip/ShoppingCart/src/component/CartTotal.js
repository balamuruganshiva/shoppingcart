import React from 'react';
import { Col, Table } from 'react-bootstrap';

export default class CartTotal extends React.PureComponent {
    render() {
        return (<Col xs lg="5"  sm="6" md="6" className="fullCutter">
            <div className="productlistmain cartBottom">
                <div className="Header">Cart Total</div>
                <div>
                    <Table striped bordered hover>
                        <tbody>
                            <tr>
                                <td>Items</td>
                                <td>{this.props.cart.items}</td>
                            </tr>
                            <tr>
                                <td>Sub Total</td>
                                <td>${this.props.cart.subTotal}</td>
                            </tr>
                            {this.props.coupon && this.props.coupon.percentage &&
                                <tr>
                                    <td>Discount: {this.props.coupon.code}</td>
                                    <td>{this.props.coupon.percentage}%</td>
                                </tr>
                            }
                            <tr>
                                <td>Total</td>
                                <td>${this.props.cart.grantTotal}</td>
                            </tr></tbody>
                    </Table>
                </div>
            </div>
        </Col>);
    }
}