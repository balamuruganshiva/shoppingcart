import React from 'react';

export default class OrderList extends React.PureComponent {
    render() {
        return (<tr>
            <td>{this.props.product.id}</td>
            <td>{this.props.product.name}</td>
            <td><div className="imgSrc"><img src={this.props.product.src} alt="OrderImage" /></div></td>
            <td>{this.props.product.qty}</td>
            <td>${this.props.product.price}</td>
            <td>${this.props.product.qty * this.props.product.price}</td>
        </tr>)
    }
}