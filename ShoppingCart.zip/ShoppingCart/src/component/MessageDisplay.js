import React from 'react';

export default class MessageDisplay extends React.PureComponent {
    render(){
        return(<div>
              <div className="messageBody">
                    <div className="messageContent">
                        {this.props.message}
                    </div>
              </div>
        </div>);
    }
}