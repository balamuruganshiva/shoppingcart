const userDetails = [
  {userName : "bala",pwd: "123456"},
  {userName : "arun",pwd: "14789"},
  {userName : "arul",pwd: "123456789"}
];
export default userDetails;