const products = [
    {
        "name" :"iPhone",
        "id" : 1,
        "price" : 25000,
        "qty" : 10,
        "src" : "https://cdn2.gsmarena.com/vv/pics/apple/apple-ipad-air3-2019-1.jpg"
    },
    {
        "name" :"Nokia",
        "id" : 2,
        "price" : 15000,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/nokia/nokia-x5-51-plus-1.jpg"
    },
    {
        "name" :"Redmi",
        "id" : 3,
        "price" : 10000,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/xiaomi/xiaomi-redmi-k20pro-2.jpg"
    },
    {
        "name" :"Samsung",
        "id" : 4,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/samsung/samsung-galaxy-s10-5g-2.jpg"
    },
    {
        "name" :"Oppo",
        "id" : 5,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/oppo/oppo-reno-z-1.jpg"
    },
    {
        "name" :"Oppo1",
        "id" : 6,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/oppo/oppo-reno-z-1.jpg"
    },
    {
        "name" :"Oppo2",
        "id" : 7,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/oppo/oppo-reno-z-1.jpg"
    },
    {
        "name" :"Oppo3",
        "id" : 8,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/oppo/oppo-reno-z-1.jpg"
    },
    {
        "name" :"Oppo4",
        "id" : 9,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/oppo/oppo-reno-z-1.jpg"
    },
    {
        "name" :"iPhone",
        "id" : 9,
        "price" : 25000,
        "qty" : 10,
        "src" : "https://cdn2.gsmarena.com/vv/pics/apple/apple-ipad-air3-2019-1.jpg"
    },
    {
        "name" :"Nokia",
        "id" : 10,
        "price" : 15000,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/nokia/nokia-x5-51-plus-1.jpg"
    },
    {
        "name" :"Redmi",
        "id" : 11,
        "price" : 10000,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/xiaomi/xiaomi-redmi-k20pro-2.jpg"
    },
    {
        "name" :"Samsung",
        "id" : 12,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/samsung/samsung-galaxy-s10-5g-2.jpg"
    },
    {
        "name" :"iPhone",
        "id" : 13,
        "price" : 25000,
        "qty" : 10,
        "src" : "https://cdn2.gsmarena.com/vv/pics/apple/apple-ipad-air3-2019-1.jpg"
    },
    {
        "name" :"Nokia",
        "id" : 14,
        "price" : 15000,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/nokia/nokia-x5-51-plus-1.jpg"
    },
    {
        "name" :"Redmi",
        "id" : 15,
        "price" : 10000,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/xiaomi/xiaomi-redmi-k20pro-2.jpg"
    },
    {
        "name" :"Samsung",
        "id" : 16,
        "price" : 7500,
        "qty" : 5,
        "src" : "https://cdn2.gsmarena.com/vv/pics/samsung/samsung-galaxy-s10-5g-2.jpg"
    }
];
export default products;