const couponCodes = [
    {code: "BALA10", percentage:10},
    {code: "BALA20", percentage:20},
    {code: "BALA30", percentage:30}
];
export default couponCodes;