import { get } from 'lodash'

export const getProduct = (products, id) => {
    if(products){
        const product = products.filter(product => product.id === id); 
        return product[0];
    }else{
        return [];
    }
}

export const getProductList = (state,keyValue) => {
      return get(state,keyValue,[]);
}

export const getCartProducts = (state, keyValue) => {
    return get(state,keyValue,[]);
}

export const getCart = (state, keyValue) => {
    return get(state, keyValue);
}

export const getCartTotal = (state, keyValue) => {
    return get(state, keyValue);
}

export const getCartCoupon = (state, keyValue) => {
    return get(state, keyValue);
}

export const getPaymentInfo = (state, keyValue) => {
    return get(state, keyValue);
}

export const getOrderProducts= (state, keyValue) => {
    return get(state, keyValue);
}

export const getOrderTotal= (state, keyValue) => {
    return get(state, keyValue);
}

export const getOrderCoupon= (state, keyValue) => {
    return get(state, keyValue);
}

export const getOrderTotals= (state, keyValue) => {
    return get(state, keyValue);
}

export const getOrderPayment= (state, keyValue) => {
    return get(state, keyValue);
}

export const getOrder = (state, keyValue) => {
    return get(state, keyValue);
}

export const getErrorMsg = (state, keyValue) => {
    return get(state, keyValue);
}


export const getUser = (state, keyValue) => {
    return get(state, keyValue);
}